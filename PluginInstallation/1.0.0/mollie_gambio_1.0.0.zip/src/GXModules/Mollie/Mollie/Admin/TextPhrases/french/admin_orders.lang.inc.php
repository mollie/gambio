<?php

$t_language_text_section_content_array = array(
    'CANCEL_ORDERS_ERROR' => 'The order could not be cancelled. Please use refund option instead.',
);