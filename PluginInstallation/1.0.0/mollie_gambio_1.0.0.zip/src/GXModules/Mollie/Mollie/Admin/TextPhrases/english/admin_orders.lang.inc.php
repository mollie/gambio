<?php

$t_language_text_section_content_array = array(
    'CANCEL_ORDERS_ERROR' => 'The orders could not be cancelled. Please use refund option instead.',
);