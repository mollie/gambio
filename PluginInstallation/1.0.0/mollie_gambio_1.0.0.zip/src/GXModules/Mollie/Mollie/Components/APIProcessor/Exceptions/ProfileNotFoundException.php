<?php

namespace Mollie\Gambio\APIProcessor\Exceptions;

use Mollie\Infrastructure\Exceptions\BaseException;

/**
 * Class ProfileNotFoundException
 *
 * @package Mollie\Gambio\APIProcessor\Exceptions
 */
class ProfileNotFoundException extends BaseException
{

}