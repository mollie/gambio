<?php


namespace Mollie\Gambio\APIProcessor\Exceptions;

/**
 * Class RefundFormNotValidException
 *
 * @package Mollie\Gambio\APIProcessor\Exceptions
 */
class RefundFormNotValidException extends \Exception
{

}