<?php

namespace Mollie\Gambio\APIProcessor\Exceptions;

use Mollie\Infrastructure\Exceptions\BaseException;

/**
 * Class FileUploadException
 *
 * @package Mollie\Gambio\APIProcessor\Exceptions
 */
class FileUploadException extends BaseException
{

}