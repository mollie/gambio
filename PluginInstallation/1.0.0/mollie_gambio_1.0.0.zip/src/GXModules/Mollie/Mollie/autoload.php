<?php

use Mollie\Gambio\BootstrapComponent;

require_once __DIR__ . '/vendor/autoload.php';

BootstrapComponent::init();