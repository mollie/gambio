<?php

define('MODULE_ORDER_TOTAL_MOLLIE_HEADER', 'Mollie Payment Surcharge');
define('MODULE_ORDER_TOTAL_MOLLIE_TITLE', 'Mollie Payment Surcharge');
define('MODULE_ORDER_TOTAL_MOLLIE_DESCRIPTION', 'Calculation of the Mollie payment methods');

define('MODULE_ORDER_TOTAL_MOLLIE_STATUS_TITLE', 'Enabled');
define('MODULE_ORDER_TOTAL_MOLLIE_STATUS_DESC', 'Enable Mollie surcharge');
define('MODULE_ORDER_TOTAL_MOLLIE_SORT_ORDER_TITLE', 'Sort order');
define('MODULE_ORDER_TOTAL_MOLLIE_SORT_ORDER_DESC', '');
define('MODULE_ORDER_TOTAL_MOLLIE_TAX_CLASS_TITLE', 'Tax Class');
define('MODULE_ORDER_TOTAL_MOLLIE_TAX_CLASS_ESC', '');