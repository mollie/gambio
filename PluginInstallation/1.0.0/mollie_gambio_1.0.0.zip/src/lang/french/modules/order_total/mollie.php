<?php

define('MODULE_ORDER_TOTAL_MOLLIE_HEADER', 'Supplément de paiement Mollie');
define('MODULE_ORDER_TOTAL_MOLLIE_TITLE', 'Supplément de paiement Mollie');
define('MODULE_ORDER_TOTAL_MOLLIE_DESCRIPTION', 'Calcul des moyens de paiement Mollie');

define('MODULE_ORDER_TOTAL_MOLLIE_STATUS_TITLE', 'Activé');
define('MODULE_ORDER_TOTAL_MOLLIE_STATUS_DESC', 'Activer le supplément Mollie');
define('MODULE_ORDER_TOTAL_MOLLIE_SORT_ORDER_TITLE', "Organiser l'ordre");
define('MODULE_ORDER_TOTAL_MOLLIE_SORT_ORDER_DESC', '');
define('MODULE_ORDER_TOTAL_MOLLIE_TAX_CLASS_TITLE', 'Catégorie de taxe');
define('MODULE_ORDER_TOTAL_MOLLIE_TAX_CLASS_ESC', '');