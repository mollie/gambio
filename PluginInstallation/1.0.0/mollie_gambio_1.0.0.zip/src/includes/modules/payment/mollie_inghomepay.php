<?php

require_once __DIR__ . '/mollie/mollie.php';

/**
 * Class mollie_inghomepay
 */
class mollie_inghomepay extends mollie
{
    public $title = "ING Home'Pay";
}