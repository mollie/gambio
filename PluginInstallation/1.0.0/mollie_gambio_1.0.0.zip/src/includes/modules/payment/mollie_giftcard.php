<?php

require_once __DIR__ . '/mollie/mollie.php';

/**
 * Class mollie_giftcard
 */
class mollie_giftcard extends mollie
{
    public $title = 'Gift cards';
}