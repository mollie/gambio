<?php

require_once __DIR__ . '/mollie/mollie.php';

/**
 * Class mollie_banktransfer
 */
class mollie_banktransfer extends mollie
{
    public $title = 'Bank transfer';
}