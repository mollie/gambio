<?php

require_once __DIR__ . '/mollie/mollie.php';

/**
 * Class mollie_giropay
 */
class mollie_giropay extends mollie
{
    public $title = 'Giropay';
}