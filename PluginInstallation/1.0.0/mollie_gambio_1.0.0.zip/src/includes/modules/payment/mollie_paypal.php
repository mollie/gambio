<?php

require_once __DIR__ . '/mollie/mollie.php';

/**
 * Class mollie_paypal
 */
class mollie_paypal extends mollie
{
    public $title = 'PayPal';
}
