<?php

require_once __DIR__ . '/mollie/mollie.php';

/**
 * Class mollie_bancontact
 */
class mollie_bancontact extends mollie
{
    public $title = 'Bancontact';
}