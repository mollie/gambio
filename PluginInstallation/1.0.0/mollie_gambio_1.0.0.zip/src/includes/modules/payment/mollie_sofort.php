<?php

require_once __DIR__ . '/mollie/mollie.php';

/**
 * Class mollie_sofort
 */
class mollie_sofort extends mollie
{
    public $title = 'SOFORT Banking';
}
