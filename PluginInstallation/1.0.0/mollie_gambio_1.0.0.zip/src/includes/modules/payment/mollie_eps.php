<?php

require_once __DIR__ . '/mollie/mollie.php';

/**
 * Class mollie_eps
 */
class mollie_eps extends mollie
{
    public $title = 'eps';
}