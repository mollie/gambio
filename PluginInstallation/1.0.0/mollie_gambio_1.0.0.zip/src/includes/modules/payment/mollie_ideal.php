<?php

require_once __DIR__ . '/mollie/mollie.php';

/**
 * Class mollie_ideal
 */
class mollie_ideal extends mollie
{
    public $title = 'iDEAL';
}