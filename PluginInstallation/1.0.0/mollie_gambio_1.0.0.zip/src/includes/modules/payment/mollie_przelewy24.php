<?php

require_once __DIR__ . '/mollie/mollie.php';

/**
 * Class mollie_przelewy24
 */
class mollie_przelewy24 extends mollie
{
    public $title = 'Przelewy24';
}