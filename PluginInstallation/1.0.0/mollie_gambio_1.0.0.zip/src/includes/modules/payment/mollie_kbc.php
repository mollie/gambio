<?php

require_once __DIR__ . '/mollie/mollie.php';

/**
 * Class mollie_kbc
 */
class mollie_kbc extends mollie
{
    public $title = 'KBC/CBC Payment Button';
}
