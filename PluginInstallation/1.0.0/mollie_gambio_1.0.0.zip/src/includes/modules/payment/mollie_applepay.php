<?php

require_once __DIR__ . '/mollie/mollie.php';

/**
 * Class mollie_applepay
 */
class mollie_applepay extends mollie
{
    public $title = 'Apple Pay';
}