<?php

require_once __DIR__ . '/mollie/mollie.php';

/**
 * Class mollie_belfius
 */
class mollie_belfius extends mollie
{
    public $title = 'Belfius Pay Button';
}